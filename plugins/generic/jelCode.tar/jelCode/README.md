JEL Code Classification plugin

Plugin that adds JEL classification in OCS PKP Software
